# Changelog & Decision Log

| | |
|---|---|
| **Version** | 1.4.0 |
| **Last updated** | 2026-08-06 |
| **Status** | Living document |
| **Related** | [Master Spec](10_MASTER_SPECIFICATION.md) · [PRD](01_PRODUCT_REQUIREMENTS.md) |

> **Purpose.** Track version history, decisions taken, ideas rejected, and future improvements. This is the record of *why* the project is the way it is.

---

## Table of Contents

1. [Version History](#1-version-history)
2. [Changes](#2-changes)
3. [Decision Log](#3-decision-log)
4. [Rejected Ideas](#4-rejected-ideas)
5. [Future Improvements](#5-future-improvements)

---

## 1. Version History

| Version | Date | Summary |
|---|---|---|
| 1.4.0 | 2026-08-06 | Defined the action flows behind every named Import and Policy control (download template, view imported records, compare with previous, reject-all-&-cancel, reprocess, roll back, save & recalculate) so none is a dead end. Surfaced by a full button-level QC. Additive; no rule changes |
| 1.3.0 | 2026-08-05 | Customisable date-range control (Today / Yesterday / This week / This month default / Last 3 months / Custom) across analytics screens, with trend charts that re-bucket to the selected range (hourly/daily/weekly/monthly). Additive; no threshold or classification changes |
| 1.2.0 | 2026-08-04 | Access-request governance: applicant submits identity + justification only (no role); admin assigns role on approval (default Read-Only); Add/Edit-user role management specified. Surfaced by the round-3 UX audit. Additive; no attendance-rule changes |
| 1.1.0 | 2026-08-03 | Added Review Log feature (US-R1 / FR20): review record + audit trail, follow-up tracking, outcome analytics, export. Additive; no business-rule changes |
| 1.0.0 | 2026-08-02 | Consolidated Phase 1 (Product Discovery) + Phase 2 (Data Discovery) into the documentation repository |
| 0.2.0 | 2026-08-02 | Phase 2 Data Discovery completed (source analysis, mappings, quality findings) |
| 0.1.1 | 2026-08-02 | PRD updated: required daily hours confirmed configurable; 8.30h set as org-wide default |
| 0.1.0 | 2026-08-02 | Phase 1 PRD produced |

## 2. Changes

**1.4.0**
- **Import & Policy action flows specified** (Dashboard Spec §12a). A full button-level QC of the prototype found controls that were named in the spec but had no defined behaviour and were inert in the build: *Download template, View imported records, Compare with previous, Reject all & cancel, Reprocess, Roll back, Save & recalculate*. Each now has a defined trigger, result, states, permissions and audit entry.
- Principle added: a visible-but-inert control is a defect; every control resolves to a result, a confirm-then-result, a disabled state with a reason, or a permission/flag-hidden state.
- Additive; no attendance rule, threshold or classification changes.
- **Implemented in the prototype:** all seven flows are now wired — Download template, View imported records, Compare with previous, Reject all & cancel, Reprocess and Roll back (with confirmation + permission gating), and Save & recalculate (with recalculation state + audit).

**1.3.0**
- **Customisable date range** added to every analytics screen. Presets: Today, Yesterday, This week, **This month (default, unchanged)**, Last 3 months, Custom range. Calendar-aligned by default; a rolling-window mode is a configurable option.
- **Trend charts re-bucket to the range** (hourly / daily / weekly / monthly) so the x-axis stays honest; a range too short for a trend shows a single summary value rather than a one-point line. Previous-period comparison becomes "vs previous period" of equal length.
- Business rules, thresholds and classifications unchanged — only the window metrics are computed over. Added Dashboard Spec §17a/§17b; updated UX Decisions §7.

**1.2.0**
- **Access-request governance clarified and tightened** (surfaced by the round-3 UX audit). The applicant's request form captures identity + optional justification only and **must not** offer a role; the administrator **assigns the role on approval**, defaulting to least-privilege Read-Only. Approve/decline and role changes are audited.
- Added **Permission Matrix §3a** (Access-Request & Role-Assignment Governance), amended the login-flow diagram, and updated User Stories **A3** and **G3** plus new **G5** (Add/Edit user with an admin-selected role); Dashboard Spec §3 and §14 updated.
- No change to attendance rules, metrics, thresholds, or the Review Log.

**1.1.0**
- Added the **Review Log** (US-R1 / FR20): a filterable, exportable record of every review with status, action taken, follow-up date and a per-review audit trail; surfaces overdue follow-ups and reports outcomes; private manager notes excluded from all listings and exports.
- Threaded additively through PRD (FR20, AC25, metrics, scope), Data Spec (§16 review + review_event entities), Permission Matrix (§5–§10 rows), Dashboard Spec (§9a screen), Master Spec (index + version).
- New user story file `05a_USER_STORY_REVIEW_LOG.md`.

**1.0.0**
- Created the 10-document repository as the single source of truth.
- Merged duplicated content; centralised the 24 acceptance criteria in the PRD and pending decisions in the Master Spec.
- Added Mermaid diagrams (architecture, roadmap, login flow, absence decision, import idempotency, data lineage, navigation).

**0.1.1**
- Required daily hours made an explicit configurable policy value (like the 20% threshold).
- **Org-wide default confirmed as 8.30 hours (8h30m = 510 min);** 9 hours is an admin override.

## 3. Decision Log

| ID | Decision | Rationale | Status |
|---|---|---|---|
| DEC-01 | Required daily hours default = **8.30 hours (510 min)**, configurable per policy, 9h as override | Matches the employee master; keeps policy out of code | ✅ Confirmed |
| DEC-02 | **Effective Hours is authoritative** for worked time | Already resolves overnight shifts to the minute in the sample | ✅ Confirmed |
| DEC-03 | **Absence never inferred from a missing row** | Prevents false accusations; highest-consequence correctness | ✅ Confirmed |
| DEC-04 | Resolve hierarchy from **master IDs only**, never the daily manager name | Daily file's manager column is display-only | ✅ Confirmed |
| DEC-05 | **Daily export is authoritative** over the monthly status report in the MVP | Avoids two classifications of one day; reconciliation deferred | ✅ Confirmed (revisit PD8) |
| DEC-06 | Flexible-shift staff **exempt from lateness** until a core start is configured | No scheduled start exists to measure against | ✅ Confirmed (revisit PD4) |
| DEC-07 | Only **Approved** leave excuses absence | Pending/Rejected/Cancelled are not commitments | ✅ Confirmed |
| DEC-08 | **Idempotent imports** via SHA-256 fingerprint + logical key `emp+date+type` | Safe daily re-uploads | ✅ Confirmed |
| DEC-09 | **Modular monolith** for the first release | Simplicity over premature microservices | ✅ Recommended (ratify in ADR) |
| DEC-10 | **Super-admin cannot be removed** if final | Prevents accidental lockout | ✅ Confirmed |
| DEC-11 | Recommended employee master **adds machine-readable fields** (real start/end times, Required Daily Minutes, numeric working days) while keeping all existing columns | Removes parsing ambiguity without breaking exports | ✅ Confirmed |
| DEC-12 | **Review Log** records reviews, actions and follow-ups with a per-review audit trail; private notes never exported; "No action required" is a first-class outcome | Closes the review loop without becoming a scoring or disciplinary surface | ✅ Confirmed |
| DEC-13 | **Access requests carry no applicant-chosen role; the administrator assigns the role on approval (default Read-Only)** | Preserves least-privilege; keeps the access decision with admins, not requesters | ✅ Confirmed |
| DEC-15 | **Every named control on the Import and Policy screens has a defined flow; a visible-but-inert control is a defect** | Traceability and trust — administrators must be able to act on what the UI offers | ✅ Confirmed |
| DEC-14 | **Date range is user-customisable (default This month unchanged); trend charts re-bucket to the selected range** | Managers ask daily, weekly and quarterly questions; fixed weekly buckets under a variable range would misrepresent the data | ✅ Confirmed |

## 4. Rejected Ideas

| Idea | Why rejected |
|---|---|
| Single hidden "attendance score" driving decisions | Punitive and opaque; replaced by explainable components shown separately |
| Inferring absence from an empty attendance row | Produces false absences; leave/holiday/weekly-off/coverage overlay required |
| Joining attendance to hierarchy by manager **name** | Names are ambiguous and display-only; IDs are the key |
| Treating remote work as negative by default | Remote is neutral; flagged only vs policy/arrangement |
| Employee-facing attendance view in the MVP | Needs controlled self-service design; deferred to Phase 2 |
| Microservices from day one | Unjustified complexity for an internal tool at this scale |

## 5. Future Improvements

Deferred to Phase 2 and beyond (see [PRD §15](01_PRODUCT_REQUIREMENTS.md#15-phase-2-scope-deferred-features)):
- Employee self-service; email alert digests with snooze/ack; manual HR exceptions with supporting files.
- Cohort/trend analysis, period comparison vs quarter & org averages, team-capacity/wellbeing signals, "what changed" summary.
- Monthly status-report import + reconciliation; early-departure & overnight metrics as first-class; PDF export styling; subject-access/data-deletion workflows; UI import roll-back.
